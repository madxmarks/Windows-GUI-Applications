﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;  

namespace WindowsFormsApp2
{ 
    public partial class Form1 : Form
    {
        Graphics g;
        bool drw;
        Pen pen;
        int beginX, beginY;
        Color colorToDraw;
        int zoom;
        int limitZoom;
        Bitmap Bitmaping;


        private enum MyShape
        {
           Pen, Line, Ellipse, Rectangle
        }

        // Define the current shape used
        private MyShape currShape;

        public Form1()
        {
            Bitmaping = null;
            zoom = 1;
            limitZoom = 60;
            colorToDraw = Color.Black;
            InitializeComponent();
            g = panel1.CreateGraphics();
           
            pen = new Pen(colorToDraw, 4);
            pen.SetLineCap(System.Drawing.Drawing2D.LineCap.Round, System.Drawing.Drawing2D.LineCap.Round, System.Drawing.Drawing2D.DashCap.Flat); 
            //   panel1.BackColor = Color.White;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            drw = true;
            beginX = e.X;
            beginY = e.Y;
            pen.Width = Convert.ToInt32(textBox1.Text);
        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        { 
            if(currShape.Equals(MyShape.Pen))
            {
                MyPen(e);
            }

        } 

        private void panel1_MouseUp(object sender, MouseEventArgs e)
        {
            drw = false;
            if (currShape.Equals(MyShape.Line))
            {
                myLine(e);
            }
        }

        /// Draw functionality 
        private void myLine(MouseEventArgs e)
        {
            Point point1 = new Point(beginX, beginY);
            Point point2 = new Point(e.X, e.Y);
            g.DrawLine(pen, point1, point2);
        }

        private void MyPen(MouseEventArgs e)
        {
            Point point1 = new Point(beginX, beginY);
            Point point2 = new Point(e.X, e.Y);
            if (drw == true)
            {
                g.DrawLine(pen, point1, point2);
                beginX = e.X;
                beginY = e.Y;
            }
        }

        /// Color change functionality
        private PictureBox OldColorSender;
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            PictureBox p = (PictureBox)sender;
            pen.Color = p.BackColor;
            colorToDraw = p.BackColor;
            /// mark a color that was picked
            if (OldColorSender != null)
                OldColorSender.BorderStyle = BorderStyle.FixedSingle;
            OldColorSender = p;
            p.BorderStyle = BorderStyle.Fixed3D;
        }

        private void Color_Click(object sender, EventArgs e)
        {
            DialogResult ColorPicker = colorDialog1.ShowDialog();
            if (ColorPicker == System.Windows.Forms.DialogResult.OK)
            {
                pen.Color = colorDialog1.Color;
                /// set background color to one that is picked, adjust color of forecolor depending on background
                Button b = (Button)sender;
                b.BackColor = colorDialog1.Color;
                if (colorDialog1.Color.GetBrightness() < 0.5f)
                    b.ForeColor = Color.White;
                else
                    b.ForeColor = Color.Black;
            }
        }

        /// change shapes of drawing
        private void buttonPen_Click(object sender, EventArgs e)
        {
            currShape = MyShape.Pen;
        }

        private void Line_Click(object sender, EventArgs e)
        {
            currShape = MyShape.Line;
        }


        /// clear 
        private void Clear_Click(object sender, EventArgs e)
        {
            panel1.Invalidate();
        }

        /// save functionality it's quite complicated because it takes screen of panel1
        private void Save_Click(object sender, EventArgs e)
        {
            int width = panel1.Size.Width;
            int height = panel1.Size.Height;

            using (Bitmap bm = new Bitmap(width, height))
            {
            Graphics graphics = Graphics.FromImage(bm);
            Rectangle rect = panel1.RectangleToScreen(panel1.ClientRectangle);
            graphics.CopyFromScreen(rect.Location, Point.Empty, panel1.Size);

            SaveFileDialog sf = new SaveFileDialog();
            sf.Filter = "Bitmap Image (.bmp)|*.bmp|Gif Image (.gif)|*.gif|JPEG Image (.jpeg)|*.jpeg|Png Image (.png)|*.png|Tiff Image (.tiff)|*.tiff|Wmf Image (.wmf)|*.wmf";
            //sf.ShowDialog();
            if (sf.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
            var path = sf.FileName;
                    bm.Save(path);
                }
            }
        }

        /// <summary>
        /// size functionality
        /// </summary>
        bool mouseClicked = false;
        private void size_MouseUp(object sender, MouseEventArgs e)
        {
            mouseClicked = false;
        }

        private void size_MouseMove(object sender, MouseEventArgs e)
        {
            if (mouseClicked)
            {
                this.panel1.Height = size.Top + e.Y; 
                this.size.Height = size.Top + e.Y;
                this.panel1.Width = size.Left + e.X;
                this.size.Width = size.Left + e.X;
                g = panel1.CreateGraphics();
                
            }
        }

        private void size_MouseDown(object sender, MouseEventArgs e)
        {
            zoom = 1;
            mouseClicked = true;
            size.BringToFront();
        }

        /*
        /// zoooooooom
        private void zoomIn_Click(object sender, EventArgs e)
        {
            zoom *= 2;
            Bitmaping = Coping();
            int width = panel1.Size.Width;
            int height = panel1.Size.Height;
            panel1.Size = new Size(zoom * width, zoom * height);

        }


        private Bitmap Coping ()
        {
            int width = panel1.Size.Width;
            int height = panel1.Size.Height;
            using (Bitmap bm = new Bitmap(width, height))
            { 
                Graphics graphics = Graphics.FromImage(bm);
                Rectangle rect = panel1.RectangleToScreen(panel1.ClientRectangle);
                graphics.CopyFromScreen(rect.Location, Point.Empty, panel1.Size);
            return bm;
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            if (Bitmaping != null)
            {
            int width = panel1.Size.Width;
            int height = panel1.Size.Height; 
            e.Graphics.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.NearestNeighbor;
            e.Graphics.DrawImage(Bitmaping, 0, 0, width * zoom, height * zoom);
            }
        }

        private void zoomOut_Click(object sender, EventArgs e)
        {
            Bitmaping = Coping();
            if ( zoom >= 1)
            { 
            zoom /= 2;
            int width = panel1.Size.Width;
            int height = panel1.Size.Height;
            panel1.Size = new Size(zoom * width, zoom * height);
            }
        }
        */
        
    }
}
